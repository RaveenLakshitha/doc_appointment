<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
    <h1 class="text-2xl font-bold mb-6">Welcome, <?php echo e(auth()->user()->name); ?>!</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
            <h3 class="text-lg font-semibold">Total Users</h3>
            <p class="text-3xl font-bold text-primary"><?php echo e(\App\Models\User::count()); ?></p>
        </div>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold">Admin Access</h3>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="text-primary hover:underline">Go to Admin Panel</a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/dashboard.blade.php ENDPATH**/ ?>