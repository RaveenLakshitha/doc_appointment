
<?php
    $filters = [
        'search' => [
            'type' => 'search',
            'name' => 'search',
            'label' => __('file.search_doctors'),
            'placeholder' => __('file.search_doctors'),
            'span' => 'xl:col-span-2',
        ],
        'specialty' => [
            'type' => 'select',
            'name' => 'specialty',
            'label' => __('file.specialty'),
            'options' => $specialties ?? [],
            'span' => 'col-span-1',
        ],
        'status' => [
            'type' => 'select',
            'name' => 'status',
            'label' => __('file.status'),
            'options' => [
                'active' => 'Active',
                'inactive' => 'Inactive',
            ],
            'span' => 'col-span-1',
        ],
        'gender' => [
            'type' => 'select',
            'name' => 'gender',
            'label' => __('file.gender'),
            'options' => [
                'male' => 'Male',
                'female' => 'Female',
                'other' => 'Other',
            ],
            'span' => 'col-span-1',
        ],
        'department' => [
            'type' => 'select',
            'name' => 'department',
            'label' => __('file.department'),
            'options' => $departments ?? [],
            'span' => 'col-span-1',
        ],
    ];
?>

<div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5 mb-6">
    <form id="filter-form" class="space-y-4">
        <?php echo csrf_field(); ?>

        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="<?php echo e($filter['span'] ?? 'col-span-1'); ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($filter['type'] === 'search'): ?>
                        <input 
                            type="text" 
                            name="<?php echo e($filter['name']); ?>" 
                            value="<?php echo e(request($filter['name'])); ?>" 
                            placeholder="<?php echo e($filter['placeholder']); ?>"
                            class="w-full px-4 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-900 dark:text-white transition-all"
                            data-filter-type="search">
                    <?php elseif($filter['type'] === 'select'): ?>
                        <label class="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                            <?php echo e($filter['label']); ?>

                        </label>
                        <select 
                            name="<?php echo e($filter['name']); ?>" 
                            class="w-full px-4 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-900 dark:text-white transition-all appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%2212%27%20height=%278%27%20viewBox=%270%200%2012%208%27%3E%3Cpath%20fill=%27%23374151%27%20d=%27M0%200l6%208%206-8z%27/%3E%3C/svg%3E')] bg-no-repeat bg-right-2 pr-8"
                            data-filter-type="select">
                            <option value=""><?php echo e(__('file.all')); ?> <?php echo e($filter['label']); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $filter['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optKey => $optValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option 
                                    value="<?php echo e($optKey); ?>" 
                                    <?php echo e(request($filter['name']) == $optKey ? 'selected' : ''); ?>>
                                    <?php echo e($optValue); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            
            <div class="flex items-end col-span-1">
                <a href="<?php echo e(route('doctors.index')); ?>" 
                   class="w-full px-4 py-2.5 text-center text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors">
                    <svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                    Clear
                </a>
            </div>
        </div>

        
        <?php
            $activeFilters = collect($filters)
                ->filter(fn($f) => request($f['name']))
                ->map(fn($f) => ['key' => $f['name'], 'label' => $f['label'] ?? ucfirst($f['name'])])
                ->values();
        ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeFilters->count() > 0): ?>
            <div class="pt-4 border-t border-gray-200 dark:border-gray-700">
                <p class="text-xs font-medium text-gray-600 dark:text-gray-400 mb-2">
                    Active Filters:
                </p>
                <div class="flex flex-wrap gap-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $activeFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $active): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-xs font-medium rounded-full border border-blue-200 dark:border-blue-800">
                            <strong><?php echo e($active['label']); ?>:</strong> <?php echo e(request($active['key'])); ?>

                            <a href="#" data-remove-filter="<?php echo e($active['key']); ?>" class="hover:text-blue-900 dark:hover:text-blue-100">
                                <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                </svg>
                            </a>
                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </form>
</div>

<script>
    // Initialize filters
    const filterForm = document.getElementById('filter-form');
    const searchInput = filterForm.querySelector('[data-filter-type="search"]');
    let debounceTimer;

    // Setup filter listeners
    const setupFilterListeners = () => {
        // Select filters - instant apply
        filterForm.querySelectorAll('[data-filter-type="select"]').forEach(select => {
            select.addEventListener('change', () => applyFilters());
        });

        // Search - debounced
        if (searchInput) {
            searchInput.addEventListener('input', () => {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => applyFilters(), 450);
            });
        }

        // Remove individual filter tags
        filterForm.querySelectorAll('[data-remove-filter]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const filterKey = btn.dataset.removeFilter;
                const input = filterForm.querySelector(`[name="${filterKey}"]`);
                if (input) input.value = '';
                applyFilters();
            });
        });
    };

    function applyFilters() {
        const params = new URLSearchParams(new FormData(filterForm));

        // Remove empty values
        for (let [key, value] of [...params.entries()]) {
            if (!value) params.delete(key);
        }

        // Preserve sort/direction
        const current = new URLSearchParams(window.location.search);
        if (!params.has('sort')) params.set('sort', current.get('sort') || 'name');
        if (!params.has('direction')) params.set('direction', current.get('direction') || 'asc');

        const url = '<?php echo e(route('doctors.index')); ?>?' + params.toString();

        fetch(url, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(r => r.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const newContainer = doc.querySelector('#doctors-container');
            if (newContainer) {
                document.getElementById('doctors-container').innerHTML = newContainer.innerHTML;
                history.replaceState(null, '', url);
                bindTableEvents();
            }
        })
        .catch(err => console.error('Filter error:', err));
    }

    // Initial setup
    setupFilterListeners();
</script><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/doctors/partials/filters.blade.php ENDPATH**/ ?>