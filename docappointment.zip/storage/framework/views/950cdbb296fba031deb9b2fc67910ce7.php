<div id="doctors-container">
    <?php echo $__env->make('doctors.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/doctors/partials/table-wrapper.blade.php ENDPATH**/ ?>