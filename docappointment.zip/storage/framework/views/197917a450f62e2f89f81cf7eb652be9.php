<div class="btn-group btn-group-sm" role="group">
    <a href="<?php echo e(route('doctors.show', $doctor)); ?>" class="btn btn-info text-white" title="View">
        <i class="bi bi-eye"></i>
    </a>
    <a href="<?php echo e(route('doctors.edit', $doctor)); ?>" class="btn btn-warning text-white" title="Edit">
        <i class="bi bi-pencil"></i>
    </a>
    <form action="<?php echo e(route('doctors.destroy', $doctor)); ?>" method="POST" class="d-inline"
          onsubmit="return confirm('Delete this doctor?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger" title="Delete">
            <i class="bi bi-trash"></i>
        </button>
    </form>
</div><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/doctors/partials/actions.blade.php ENDPATH**/ ?>