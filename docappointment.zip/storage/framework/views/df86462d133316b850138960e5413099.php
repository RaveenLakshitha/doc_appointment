

<?php $__env->startSection('title', $doctor->full_name); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 sm:px-6 lg:px-8 py-6 sm:py-8 max-w-4xl mx-auto">
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <!-- Header -->
        <div class="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 px-6 py-5 border-b border-gray-200 dark:border-gray-700">
            <div class="flex items-center gap-4">
                <div class="w-20 h-20 rounded-full overflow-hidden bg-gray-200 dark:bg-gray-700 border-2 border-dashed border-gray-300 dark:border-gray-600">
                    <?php if($doctor->profile_photo): ?>
                        <img src="<?php echo e(Storage::url($doctor->profile_photo)); ?>" alt="<?php echo e($doctor->full_name); ?>" class="w-full h-full object-cover">
                    <?php else: ?>
                        <div class="w-full h-full flex items-center justify-center text-gray-400 dark:text-gray-500">
                            <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                            </svg>
                        </div>
                    <?php endif; ?>
                </div>
                <div>
                    <h1 class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($doctor->full_name); ?></h1>
                    <p class="text-sm text-gray-600 dark:text-gray-400">
                        <?php echo e($doctor->primary_specialty); ?> 
                        <?php if($doctor->secondary_specialty): ?> • <?php echo e($doctor->secondary_specialty); ?> <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Details Grid -->
        <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Contact Info -->
            <div>
                <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider mb-3"><?php echo e(__('file.contact')); ?></h3>
                <dl class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.email')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium"><?php echo e($doctor->email ?? '—'); ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.phone')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium"><?php echo e($doctor->phone ?? '—'); ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.address')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium text-right">
                            <?php echo e($doctor->address ? "{$doctor->address}, {$doctor->city}, {$doctor->state} {$doctor->zip_code}" : '—'); ?>

                        </dd>
                    </div>
                </dl>
            </div>

            <!-- Professional Info -->
            <div>
                <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider mb-3"><?php echo e(__('file.professional')); ?></h3>
                <dl class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.license')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-mono"><?php echo e($doctor->license_number ?? '—'); ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.expiry')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium">
                            <?php echo e($doctor->license_expiry_date ? \Carbon\Carbon::parse($doctor->license_expiry_date)->format('M d, Y') : '—'); ?>

                        </dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.department')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium"><?php echo e($doctor->department ?? '—'); ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.position')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium"><?php echo e($doctor->position ?? '—'); ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.hourly_rate')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium">$<?php echo e(number_format($doctor->hourly_rate, 2)); ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.appointments')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium"><?php echo e($doctor->appointments_count); ?></dd>
                    </div>
                </dl>
            </div>

            <!-- Personal Info -->
            <div>
                <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider mb-3"><?php echo e(__('file.personal')); ?></h3>
                <dl class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.dob')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium">
                            <?php echo e($doctor->date_of_birth ? \Carbon\Carbon::parse($doctor->date_of_birth)->format('M d, Y') : '—'); ?>

                        </dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.gender')); ?></dt>
                        <dd class="text-gray-900 dark:text-white font-medium">
                            <?php echo e($doctor->gender ? ucfirst($doctor->gender) : '—'); ?>

                        </dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500 dark:text-gray-400"><?php echo e(__('file.status')); ?></dt>
                        <dd>
                            <span class="inline-flex items-center px-2.5 py-1 rounded text-xs font-medium
                                <?php echo e($doctor->is_active ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'); ?>">
                                <?php echo e($doctor->is_active ? __('file.active') : __('file.inactive')); ?>

                            </span>
                        </dd>
                    </div>
                </dl>
            </div>

            <!-- Qualifications & Certifications -->
            <div>
                <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider mb-3"><?php echo e(__('file.qualifications')); ?></h3>
                <div class="text-sm text-gray-900 dark:text-white">
                    <?php echo e($doctor->qualifications ?? '—'); ?>

                </div>
                <?php if($doctor->certifications): ?>
                    <div class="mt-3">
                        <h4 class="text-xs font-medium text-gray-600 dark:text-gray-400"><?php echo e(__('file.certifications')); ?></h4>
                        <p class="mt-1 text-sm text-gray-900 dark:text-white"><?php echo e($doctor->certifications); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-200 dark:border-gray-700 flex justify-end gap-3">
            <a href="<?php echo e(route('doctors.edit', $doctor)); ?>"
               class="inline-flex items-center px-4 py-2 bg-gray-900 dark:bg-gray-700 text-white text-sm font-medium rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                </svg>
                <?php echo e(__('file.edit')); ?>

            </a>
            <a href="<?php echo e(route('doctors.index')); ?>"
               class="inline-flex items-center px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">
                <?php echo e(__('file.back_to_list')); ?>

            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/doctors/show.blade.php ENDPATH**/ ?>