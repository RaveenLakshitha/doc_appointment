<?php
// resources/lang/en/file.php

return [
    'UserName'       => 'Username2222222222',
    'Email'          => 'Email22222222222',
    'Company Name'   => 'Company Name2222222222',
    'Phone Number'   => 'Phone Number22222222222',
    'Role'           => 'Role222222222',
    'Status'         => 'Status222222',
    'action'         => 'Action22222222',
    'Add User'       => 'Add User2222222',
    'records per page' => 'records per page22222',
    'Showing'        => 'Showing222222',
    'entries'        => 'entries22222222',
    'filtered from'  => 'filtered from2222222',
    'total entries'  => 'total entries2222222',
    'No matching records found' => 'No matching records found222222',
    'No data available in table' => 'No data available in table2222222222',
    'Search'         => 'Search222222222',
    'Are you sure want to delete?' => 'Are you sure you want to delete?222222222',
    'No user is selected!' => 'No user is selected!222222222',
    'This feature is disable for demo!' => 'This feature is disabled for demo!222222222',
];