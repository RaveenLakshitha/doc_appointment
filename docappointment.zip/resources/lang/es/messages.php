<?php
return [
    'Dashboard' => 'Tablero',
    'Admin Panel' => 'Panel de Admin',
    'User Management' => 'Gestión de Usuarios',
    'Doctors' => 'Doctores',
    'Doctors List' => 'Lista de Doctores',
    'Patients' => 'Pacientes',
    'My Appointments' => 'Mis Citas',
    'Issue Invoice' => 'Emitir Factura',
    'Book Appointment' => 'Reservar Cita',
    'Log in' => 'Iniciar Sesión',
    'Register' => 'Registrarse',
    'English' => 'Inglés',
    'Español' => 'Español',
];