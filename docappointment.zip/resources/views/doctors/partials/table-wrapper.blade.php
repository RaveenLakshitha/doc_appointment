<div id="doctors-container">
    @include('doctors.partials.table')
</div>